Prompt List — #SummerOfJune2026
SummerTime
Hair clips
Party
Beach
Fireworks
Restaurant
Selfie
Drinks
Hot Day
Swimming
Roleplays
Noodles
Picnics
BedTime
Ice Creams
BeachBalls
Tanned
Chilling Out
Meeting
Dance
WLW
MLM
Flowers
Talking
Shoppings
Bathing
Texting
Shooting Stars
Embarrassed
THE END!!!
Include the two users along with the hashtag, please.
@razzrubinodraws — #SummerOfJune2026

Collaborators: @RazzRubino + @aokileigh

SummerTime
Hair clips
Party
Beach
Fireworks
Restaurant
Selfie
Drinks
Hot Day
Swimming
Roleplays
Noodles
Picnics
BedTime
Ice Creams
BeachBalls
Tanned
Chilling Out
Meeting
Dance
WLW
MLM
Flowers
Talking
Shoppings
Bathing
Texting
Shooting Stars
Embarrassed
THE END!!!
chatGPT_MJ_Prompt_Template.md
File
Use this control file to build prompts with this data. Until I give expressed instructions to build the prompt, they'll be done on a daily basis.

Selfie, summer afternoon at a scenic overlook above the coastline, smartphone held high as friends crowd together for a spontaneous photo, wind-tousled hair, bright smiles, distant ocean shimmering beneath a brilliant blue sky, wildflowers framing the foreground, candid energy, vibrant anime slice-of-life aesthetic, warm natural sunlight, nostalgic vacation atmosphere, emotionally expressive characters, highly detailed, dreamy realism --profile 4lbi7ao lzdppsy

The photo wasn't perfect. Someone blinked, another laughed at the wrong moment, and half the group barely fit into the frame. Years later, it would become everyone's favorite picture from the summer.

June 7
Selfie
@razzrubinodraws
@RazzRubino
@aokileigh

#SummerOfJune2026 #selfie #animeart #summervibes #collabcrew

Audio:

OneRepublic — Good Life
American Authors — Best Day of My Life
Owl City & Carly Rae Jepsen — Good Time
Fitz and The Tantrums — The Walker
June 8

Drinks, colorful summer café terrace overlooking a bustling boardwalk, friends gathered around a table filled with vibrant fruit beverages, sparkling lemonade, iced tea, and tropical mocktails, condensation glistening in the afternoon sun, laughter carried on a warm ocean breeze, bright umbrellas and flower planters surrounding the scene, lively anime slice-of-life atmosphere, cheerful social energy, cinematic sunlight, dreamy summer realism, highly detailed --profile 4lbi7ao lzdppsy

The drinks arrived one by one, each more colorful than the last. What began as a quick stop to cool off turned into hours of conversation, laughter, and plans for adventures that had not happened yet.

June 8
Drinks
@razzrubinodraws
@RazzRubino
@aokileigh

#SummerOfJune2026 #drinks #animeart #summercafe #collabcrew

Audio:

Harry Styles — Watermelon Sugar
Surfaces — Sunday Best
Nicky Youre & dazy — Sunroof
Rex Orange County — Loving Is Easy
June 9

Hot Day, blazing midsummer afternoon in a lively coastal town, shimmering heat rising from sunlit streets, friends seeking shade beneath colorful awnings, handheld fans, cold treats, and iced drinks providing relief, bright blue sky without a cloud, sunlight reflecting from shop windows and pavement, vibrant anime slice-of-life aesthetic, warm seasonal atmosphere, expressive character interactions, cinematic summer lighting, nostalgic vacation mood, highly detailed, dreamy realism --profile 4lbi7ao lzdppsy

By noon, the heat had turned the whole town slow and sleepy. Nobody wanted to move faster than necessary. Even so, the day became unforgettable—not because of what they did, but because they spent it together, hiding from the sun and making memories in the shade.

June 9
Hot Day
@razzrubinodraws
@RazzRubino
@aokileigh

#SummerOfJune2026 #hotday #animeart #summervibes #collabcrew

Audio:

Katrina & The Waves — Walking on Sunshine
Len — Steal My Sunshine
DJ Jazzy Jeff & The Fresh Prince — Summertime
Vance Joy — Saturday Sun